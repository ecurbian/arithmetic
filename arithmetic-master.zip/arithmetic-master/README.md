# arithmetic
This project is just a vehicle for me to learn GitHub.
But, I will consider actually delivering on the promised arithmetic.
